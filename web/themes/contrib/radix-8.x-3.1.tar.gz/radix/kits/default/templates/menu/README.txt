
This directory should be used to place menus template files.
