
This directory should be used to place block template files.
